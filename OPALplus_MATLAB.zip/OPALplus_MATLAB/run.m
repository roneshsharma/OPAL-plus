% MoRF prediction algorithm 
%(Proposed length-specific models scores combined with scores of
% predictors MoRFpred-plus and MoRFchibi)
%
%Input
%input query sequence file (input.fasta)
%HSE_Alpha file (obtained by SPIDER2 predictor) (input.hsa2)
%HSE_Beta file (obtained by SPIDER2 predictor) (input.hsb2)
%spd3 file (obtained by SPIDER2 predictor) (input.spd3)
%MoRFpred-plus output score file  (obtained by MoRFpred-plus predictor) (scores_MoRFpred_plus.txt)
%MoRFchibi output score file (obtained by MoRFchibi predictor) (output_MoRFchibi.txt)
%
%Output
%MoRFscore: scores for each residue of the query sequence predicted by
%OPAL+ (OPAL+_ouput.txt)
%
% Ronesh Sharma, FNU, Fiji. 
% Email: sharmaronesh@yahoo.com
% Ref. Sharma et al., , 2018

clear all;
close all;

addpath('...\libsvm-3.21\matlab'); % path needs to be inserted
addpath('input');

%data
seq1 = fastaread('input.fasta'); %load seq file
seq =seq1.Sequence;
HESa1 = importdata('input.hsa2'); %load hsa2 file
sp_hsa2= HESa1.data;
HESb1 = importdata('input.hsb2'); %load hsb2 file
sp_hsb2 = HESb1.data;
spd31 = importdata('input.spd3'); %load spd3 file
sp_spd3= spd31.data;

%scores of other predictors
MoRFpred_plus_score_ = importdata('scores_MoRFpred_plus.txt'); %load MoRFpred-plus score
MoRFpred_plus_score= MoRFpred_plus_score_.data;

MoRFchibi_score_ = importdata('output_MoRFchibi.txt'); %load MoRFchibi score
MoRFchibi_score= MoRFchibi_score_.data;


%Predict using proposed model
%profile_windows_m_1 = [sp_hsa2(:,2)/100 ] ; %HSE attribute (2)  
profile_bigram_m1_m2_5_9_ = [ sp_hsa2(:,1)/100  sp_spd3(:,4)/100 sp_spd3(:,7) sp_hsb2(:,2)/100   ] ; %1 10 13 5
profile_bigram_m1_m2_10_14_ = [ sp_hsa2(:,1)/100 sp_spd3(:,1)/100 sp_hsb2(:,3)/100 sp_spd3(:,4)/100] ; %1 7 6 10
profile_bigram_m1_m2_15_19_ = [ sp_hsa2(:,1)/100 sp_spd3(:,1)/100 sp_spd3(:,6) sp_hsa2(:,3)/100 sp_spd3(:,7)] ; %1 7 12 3 13
profile_bigram_m1_m2_20_25_ = [sp_hsa2(:,1)/100 sp_spd3(:,4)/100 ] ; %1 10

%%{
ab=0;
hh=size(profile_bigram_m1_m2_5_9_,1); % check if proetin length less than total Flanking size
if hh < 42
    ab=1;
profile_bigram_m1_m2_5_9 = [zeros(round((42-hh)/2),size(profile_bigram_m1_m2_5_9_,2)); profile_bigram_m1_m2_5_9_; zeros(round((42-hh)/2),size(profile_bigram_m1_m2_5_9_,2)) ]; 
profile_bigram_m1_m2_10_14 = [zeros(round((42-hh)/2),size(profile_bigram_m1_m2_10_14_,2)); profile_bigram_m1_m2_10_14_; zeros(round((42-hh)/2),size(profile_bigram_m1_m2_10_14_,2)) ]; 
profile_bigram_m1_m2_15_19 = [zeros(round((42-hh)/2),size(profile_bigram_m1_m2_15_19_,2)); profile_bigram_m1_m2_15_19_; zeros(round((42-hh)/2),size(profile_bigram_m1_m2_15_19_,2)) ]; 
profile_bigram_m1_m2_20_25 = [zeros(round((42-hh)/2),size(profile_bigram_m1_m2_20_25_,2)); profile_bigram_m1_m2_20_25_; zeros(round((42-hh)/2),size(profile_bigram_m1_m2_20_25_,2)) ]; 

else
     profile_bigram_m1_m2_5_9=profile_bigram_m1_m2_5_9_;
     profile_bigram_m1_m2_10_14=profile_bigram_m1_m2_10_14_;
     profile_bigram_m1_m2_15_19=profile_bigram_m1_m2_15_19_;
     profile_bigram_m1_m2_20_25=profile_bigram_m1_m2_20_25_;
end

%call prediction function 
MoRFscores_m1_bi_(:,1) = test_bigram_method_4_models(profile_bigram_m1_m2_5_9,30,30,1); 
MoRFscores_m1_bi_(:,2) = test_bigram_method_4_models(profile_bigram_m1_m2_10_14,30,30,2); 
MoRFscores_m1_bi_(:,3) = test_bigram_method_4_models(profile_bigram_m1_m2_15_19,30,30,3); 
MoRFscores_m1_bi_(:,4) = test_bigram_method_4_models(profile_bigram_m1_m2_20_25,30,30,4); 

if ab==1
     MoRFscores_m1_bi = MoRFscores_m1_bi_(round((42-hh)/2)+1:end-round((42-hh)/2),:) ;
else
     MoRFscores_m1_bi=MoRFscores_m1_bi_;
end

%Process Scores
Proposed_P1 = Process_score(MoRFscores_m1_bi(:,1),25); %Process scores of proposed model_5_9
Proposed_P2 = Process_score(MoRFscores_m1_bi(:,2),25); %Process scores of proposed model10_14
Proposed_P3 = Process_score(MoRFscores_m1_bi(:,3),25); %Process scores of proposed model15_19
Proposed_P4 = Process_score(MoRFscores_m1_bi(:,4),25); %Process scores of proposed model20_25
Proposed_P = min([Proposed_P1 Proposed_P2 Proposed_P3 Proposed_P4],[],2);
Proposed_PP = Process_score(Proposed_P,25); %process proposed

MoRFpred_plus_P = Process_score(MoRFpred_plus_score(:,3),4); %Process scores of MoRFpred_plus
MoRFchibi_P = Process_score(MoRFchibi_score(:,1),15); %Process scores of MoRFchibi


Proposedcombined= (Proposed_PP+ MoRFpred_plus_P+MoRFchibi_P)/3; %Combine scores 
Proposedcombined_P = Process_score(Proposedcombined,8); %Process combined scores


fileID = fopen('Ouput_scores.txt','w');  % save scores in txt file scores.txt
fprintf(fileID,'%3s  %3s  %20s  \n','No:', 'residues','OPAL+_scores' );
for rry=1:size(Proposedcombined_P,1)
fprintf(fileID,'%0.1f  %3s  %f \n',rry,seq(rry),Proposedcombined_P(rry,1)  );
end
fclose(fileID);



