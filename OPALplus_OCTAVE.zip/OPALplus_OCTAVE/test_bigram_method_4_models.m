function [MoRFscores] = test_bigram_method_4_models(profile,Za,Zb,model)
%
% Input
%profile: 
%
% Output
% scores for each residue of the query sequence
%
% Ronesh Sharma, FNU, Fiji. 
% Email: sharmaronesh@yahoo.com
% Ref. Sharma et al., , 2018

if model==1
load SVM_model_bigram_xx_5_9_1to1_AUC2_bi_1t ; % load trained models bi m1
end
if model==2
load SVM_model_bigram_xx_10_14_1to1_AUC2_bi_1t ; % load trained models bi m1
end
if model ==3
load SVM_model_bigram_xx_15_19_1to1_AUC2_bi_1t ; % load trained models bi m1
end
if model ==4
load SVM_model_bigram_xx_20_25_1to1_AUC2_bi_1t; % load trained models bi m1
end

%load dset;
%---------------------------------------------------------------------------
kk=1;win_flank_siz= 20;
mat4=profile ; % profile
mat3 = [mat4] ; % both profiles concatenated
morf = Za:Zb; 
T_len=size(mat3,1);
coln = size(mat3,2);

for e=1:T_len
       f1=1;
          for e1=1:length(morf)
           if e<morf(e1)
             A=e;
           elseif e> T_len- morf(e1)+1
              A=T_len- e+1;
           else
              A=morf(e1); 
           end
          % A
           for e2=1:A
           if ((e<  win_flank_siz+e2 ) && (T_len< e-e2+1+morf(e1)+win_flank_siz-1)) %at start protein length less
           %'start length less'  
           matAA= mat3(1:end,:);
           sample_d1_seq = [zeros((win_flank_siz*2+morf(e1))-size(matAA,1) ,coln) ; matAA] ;  % start flanks with zeros
           elseif e < win_flank_siz+e2  % at start 
           %'start'
            matAA= mat3(1:e-e2+1+morf(e1)+win_flank_siz-1,:);
            sample_d1_seq = [zeros(win_flank_siz-(e-e2) ,coln) ; matAA] ;  % start flanks with zeros
            elseif ((e > T_len-e2- win_flank_siz)&& ((e-morf(e1)-win_flank_siz+e2)< 1) )  % at end protein length less
            %'end length less'
            matBB= mat3(1:end,:);
            sample_d1_seq = [matBB ; zeros((win_flank_siz*2+morf(e1))-size(matBB,1) ,coln) ] ;  % end flanks with zeros
            elseif e > T_len-e2-win_flank_siz  % at end
            %'end'
            matBB= mat3(e-morf(e1)-win_flank_siz+e2:end,:);
            sample_d1_seq = [matBB ; zeros((win_flank_siz*2+morf(e1))-size(matBB,1) ,coln) ];   % end flanks with zeros
            else %middle
            if e-e2+1+morf(e1)-1+1+win_flank_siz-1 > T_len
            %'middle_towards end' 
             sample_d1_seq = mat3(e-e2+1-win_flank_siz:end,:);   %middle  
             else 
             %'middle'
             sample_d1_seq = mat3(e-e2+1-win_flank_siz:e-e2+1+morf(e1)-1+1+win_flank_siz-1,:);   %middle
             end
            end
            matZ=[ sample_d1_seq];
                %bigram
                for h=1:size(matZ,2)
                  for h1=1:size(matZ,1)-1
                  Bi(h1,:)= matZ(h1,h) * matZ(h1+1,:);
                  end
                Bigram(h,:)= sum(Bi,1)/size(matZ,1);
                end
                Bigram_1= Bigram(:)';
                Bi=[];
                Bigram=[];
             F1(f1,:) = [Bigram_1];
             f1=f1+1;
         end 
         end

feature_m1=[F1]; %feature for m1
class=ones(size(feature_m1,1),1);
if model ==1
score=  indp_LibSVM_fg(feature_m1, class, SVM_model_bigram_xx_5_9_1to1_AUC2_bi_1t  ); %
end
if model ==2
score=  indp_LibSVM_fg(feature_m1, class, SVM_model_bigram_xx_10_14_1to1_AUC2_bi_1t ); %
end
if model ==3
score=  indp_LibSVM_fg(feature_m1, class, SVM_model_bigram_xx_15_19_1to1_AUC2_bi_1t  ); %
end
if model ==4
score=  indp_LibSVM_fg(feature_m1, class, SVM_model_bigram_xx_20_25_1to1_AUC2_bi_1t   ); %
end

MoRFscores_1(kk,:)= [max(score) ];
kk=kk+1;
clear sample_d1_seq;
clear feature_seq1;clear feature_seq2;clear feature_seq3;clear feature_seq4;clear F1,clear F2;clear feature_seq5;
end
mat3=[];mat4=[];
%MoRFscores=[ MoRFscores_1 MoRFscores_2];
MoRFscores=[ MoRFscores_1 ];
end
%##############################
